<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row">
    <div class="col-12">
    <table class="table text-center table-hover table-bordered">
      <thead>
        <tr>
          <th scope="col">#</th>
          <th scope="col">Name</th>
          <th scope="col">Email</th>
          <th scope="col">Action</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <th scope="row"><?php echo e($user->id); ?></th>
          <td><?php echo e($user->name); ?></td>
          <td><?php echo e($user->email); ?></td>
          <td class="d-flex justify-content-around">
            <form action="<?php echo e(route('users.show',$user->id)); ?>">
              <button type="submit" class="btn btn-sm btn-primary">Show</button>
            </form>
            <form action="<?php echo e(route('users.edit',$user->id)); ?>">
              <button type="submit" class="btn btn-sm btn-warning">Edit</button>
            </form>
            <form action="<?php echo e(route('users.destroy',$user->id)); ?>" method="post">
              <input type="hidden" name="_method" value="delete">
                <?php echo e(csrf_field()); ?>

              <button type="submit" class="btn btn-sm btn-danger">Delete</button>
            </form>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
      </table>
    </div>
  </div>
</div>

<?php echo e($users->links()); ?>

 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>